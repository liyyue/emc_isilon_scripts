isilon-hadoop-tools
===================

For documentation on using these scripts, see the following:

-  `EMC Isilon Hadoop Starter Kit for Cloudera <http://hsk-cdh.readthedocs.org/>`_
   
-  `EMC Isilon Hadoop Starter Kit for Pivotal <http://hsk-phd.readthedocs.org/>`_

-  `EMC Isilon Hadoop Starter Kit for Hortonworks <http://hsk-hwx.readthedocs.org/>`_

-  https://github.com/claudiofahey/hsk-docs

